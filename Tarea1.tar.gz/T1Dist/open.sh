#!/bin/sh

terminator --working-directory=$PWD"/cliente" &
terminator --working-directory=$PWD"//serv_distrito" &
terminator --working-directory=$PWD"/serv_central" &
