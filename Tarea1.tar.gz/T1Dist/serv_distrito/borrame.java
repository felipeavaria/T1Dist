"
public class Advertisement2 extends Thread
{
    private boolean done = false;
    String message = "";

    public void run() 
    {
        Thread myThread = Thread.currentThread();
        while (true) 
        {
            while (!done) 
            {
                System.out.println("\n\nPlease enter the advertisement message to be displayed "
                    + "(type message or enter 'n' to exit):\n");
                Scanner sc2 = new Scanner(System.in);
                message = sc2.nextLine();
                done = true;
                System.out.println("\n");
                if (message.equalsIgnoreCase("n")) 
                    {
                        System.out.println("User Stopped the Message Output");
                        // Terminating
                        System.exit(0);
                        continue;
                    }
                while (!(myThread.isInterrupted())) 
                {
                    try 
                    {
                        System.out.print("** " + message + " **");
                        Thread.sleep(1000);
                    } 
                    catch (InterruptedException e) 
                    {
                        // System.out.println("Exception caught: " + e.getMessage());
                        done = false;
                        break;

                    }
                }
            }
        }
    }// end of 'run()' ..

    /**
    * @return  done variable
    */
    synchronized public boolean isDone() 
    {
        return done;
    }    

    /**
     * @param done  to set done variable
     */
    synchronized public void setDone(boolean done)
    {
        this.done = done;
    }
